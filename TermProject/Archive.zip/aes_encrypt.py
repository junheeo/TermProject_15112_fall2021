# Name : Jun Hee Oh
# ID : junheeo

#print(f'bin(32) = {bin(32)} has type {type(bin(32))}')


# converts '0' => 0 (type int), '1' => 1 (type int), else => None
def stringBitToInt(val):
    if val == '0':
        return 0
    elif val == '1':
        return 1
    else:
        print(f"InputError: '{val}' is not a string of bit : stringBitToInt()")
        return None

# converts integer into string of binary e.g. 13 => '1101'
# the result is m digits e.g. m = 4, intVal=2 => return 0010
def intToStringBinary(intVal, m):
    max = 2 ** m - 1
    if not isinstance(intVal, int):
        print(f'InputError : intVal={intVal} is not an int'
                                                    +' : intToStringBinary()')
    elif not(0 <= intVal <= max):
        print(f'InputError: intVal = {intVal} out of range 0~2**{m}-1'
                                                    +' : intToStringBinary()')
    else:
        strBinary = bin(intVal)
        strBinary = strBinary[2:]
        return strBinary
    return None
        
# perfom addition of two integers in Galis Field 2^m
# returns binary string of m digits
def additionGF2m(int1, int2, m):

    strBinary1 = intToStringBinary(int1, m)
    strBinary2 = intToStringBinary(int2, m)
    if strBinary1 == None:
        print(f'InputError : int1 = {int1} is not valid input : additionGF2m()')
    if strBinary1 == None:
        print(f'InputError : int2 = {int2} is not valid input : additionGF2m()')

    else:   # there are no problems with input
        binarySum = ''
        strBin1Len = len(strBinary1)
        strBin2Len = len(strBinary2)
        if strBin1Len < m:
            strBinary1 = '0'*(m - strBin1Len) + strBinary1
        if strBin2Len < m:
            strBinary2 = '0'*(m - strBin2Len) + strBinary2
        strBinarySum = ''
        for i in range(m):
            bit1 = int(strBinary1[i])
            bit2 = int(strBinary2[i])
            bitSum = bit1 ^ bit2
            strBinarySum += str(bitSum)
        return strBinarySum
    # if there is error with input return None
    return None


# This is NOT the entire multiplication code for GF(2**m)
# executed only the polynomial multiplication of two strings of Binary of size m
# no modulo operation is executed
def polynomialMult(strBinary1, strBinary2, m):
    polyMultResult = "0"
    trailingZeros = ''
    strBin2Len = len(strBinary2)
    for strB2Inx in range(strBin2Len - 1, -1, -1):
        newDigit = '0'
        if strBinary2[strB2Inx] == '1':
            newDigit = strBinary1 + trailingZeros
        intVerNewDigit = int(newDigit, 2)
        intVerPolyMultResult = int(polyMultResult, 2)
        polyMultResult = additionGF2m(intVerPolyMultResult, intVerNewDigit, m*2)
        trailingZeros += '0'
    return polyMultResult

# Do: binarystring mod binary string
# doing polynomial modulo operation under GF(2^m)
# return the moduloed result binary string
def polynomialModulo(polyMultResult, strBinaryP, m):
    m = m * 2
    polyMultResult = bin(int(polyMultResult, 2))[2:]
    lenPolyMultResult = len(polyMultResult)
    #print(f'm = {m}')
    #print(f'lenPolyMultResult = {lenPolyMultResult}')
    if lenPolyMultResult < m:
        polyMultResult = '0'*(m - lenPolyMultResult) + polyMultResult
    lenPolyMultResult = len(polyMultResult)
    lenStrBinP = len(strBinaryP)
    if lenStrBinP > lenPolyMultResult:
        return polyMultResult
    #print(f'{polyMultResult} mod {strBinaryP}')
    for inx in range(lenPolyMultResult - lenStrBinP + 1):
        #print(f'\tinx = {inx}')
        #print(f'\tpolyMultResult[inx] = {polyMultResult[inx]}')
        if polyMultResult[inx] == '1':
            alter = additionGF2m(int(polyMultResult[:lenStrBinP + inx], 2)
                                                        , int(strBinaryP, 2)
                                                            , lenStrBinP)
            rest = polyMultResult[lenStrBinP + inx:]
            polyMultResult = alter + rest
            lenPolyMultResult = len(polyMultResult)
            if lenPolyMultResult < m:
                polyMultResult = '0'*(m - lenPolyMultResult) + polyMultResult
        #print(f'\t=> polyMultResult = {polyMultResult}')
    polyMultResult = bin(int(polyMultResult, 2))[2:]
    return polyMultResult

# performs multiplication of two integers in Galois Field of 2^m with
# p an integer representing the irreducible polynomial
# returns binary string of m digits
def multiplicationGF2m(int1, int2, p, m):
    noInputError = True
    if not isinstance(p, int):
        print(f'InputError : p = {p} should be an int : multiplicationGF2m()')
        noInputError = False
    strBinaryP = bin(p)[2:]
    if not isinstance(m, int):
        print(f'InputError : m = {m} should be an int : multiplicationGF2m()')
        noInputError = False
    
    strBinary1 = None
    if intToStringBinary(int1, m) != None:
        strBinary1 = bin(int1)[2:]  # does not have leading zeros
    strBinary2 = intToStringBinary(int2, m)
    if strBinary1 == None:
        print(f'InputError : int1 = {int1} is not valid input '
                                                    +': multiplicationGF2m()')
        noInputError = False
    if strBinary2 == None:
        print(f'InputError : int2 = {int2} is not valid input '
                                                    +': multiplicationGF2m()')
        noInputError = False

    if noInputError:       
        polyMultResult = polynomialMult(strBinary1, strBinary2, m)
        polyMultModuloResult = polynomialModulo(polyMultResult, strBinaryP, m)
        return polyMultModuloResult
    else:
        return None

# addition of two hex values in GF(2^m)
# return hex value
# input and output hex vals do NOT include "0x"
def hexAdd(hexVal1, hexVal2, m):
    int1 = int(hexVal1, 16)
    int2 = int(hexVal2, 16)
    return hex(int(additionGF2m(int1, int2, m), 2))[2:]

# multiplication of two hex values in GF(2^m) with mod p (p is INT)
# return hex value
# input and output hex vals do NOT include "0x"
def hexMult(hexVal1, hexVal2, p, m):
    int1 = int(hexVal1, 16)
    int2 = int(hexVal2, 16)
    return hex(int(multiplicationGF2m(int1, int2, p, m), 2))[2:]

# matrix multiplication between matrix and column vector
# return column vector
# all values except p, m are in hex without '0x'
def matXColvecGF2m(mat, vec, p, m):
    matNumRow = len(mat)
    matNumCol = len(mat[0])
    if len(vec) != matNumCol:
        print('InputError : maxtrix and vector dimensions do not match '
                                                            +': aesMixCol()')
    resultColVec = []
    for row in mat:
        rowXCol = '0'
        for inx in range(matNumCol):
            rowXCol = hexAdd(rowXCol, hexMult(row[inx], vec[inx], p, m), 2 * m)
            #print(f'rowXCol = {rowXCol}')
        resultColVec.append(rowXCol)
    #print(f'resultColVec = {resultColVec}')
    return resultColVec

# hex = 16 bits (0~F)
# two digit hex = 16 * 16 digits
#
# mixCol Layer implementation
#
# input : list of 4 hex values each with 2 digits
# output : list of 4 hex values each with 2 digits
#
#  | 02 03 01 01 |   | B0 |   | C0 |
#  | 01 02 03 03 | * | B5 | = | C1 |
#  | 01 01 02 03 |   | B10|   | C2 |
#  | 03 01 01 01 |   | B15|   | C3 |
def aesMixCol(hexVectorL):
    noInputError = True
    if len(hexVectorL) != 4:
        print(f'InputError : hexVectorL = {hexVectorL} is incorrect vector '
                                                    +'input size : aesMixCol()')
        notInputError = False
    for inputVecVal in hexVectorL:
        if not isinstance(inputVecVal, str):
            print(f'InputError : hexVectorL = {hexVectorL} should represent '
                                            +' hex with string : aesMixCol()')
            notInputError = False
        else:
            if not inputVecVal.isalnum():
                notInputError = False
                print(f'InputError : hexVectorL = {hexVectorL} should '
                                                +'represent hex : aesMixCol()')
            else:
                if inputVecVal[:2] == '0x' or inputVecVal[:2] == '0X':
                    notInputError = False
                    print(f'InputError : hexVectorL = {hexVectorL} should '
                            +'represent hex without 0x infront : aesMixCol()')
                    if len(inputVecVal) > 2:
                        notInputError = False
                        print(f'InputError : hexVectorL = {hexVectorL} should '
                                +'represent 2 digit hex : aesMixCol()')
                        print('2**8 = 2**4 * 2**4 = 16 * 16 = 0xFF')
    if noInputError:
        mat0 = [
        ['02', '03', '01', '01'],
        ['01', '02', '03', '01'],
        ['01', '01', '02', '03'],
        ['03', '01', '01', '02']
        ]
        return matXColvecGF2m(mat0, hexVectorL, 283, 8)








def testGF2mArithmetic():
    print(f'\ntesting arithmetic in GF...')
    assert(stringBitToInt('0') == 0)
    assert(stringBitToInt('1')== 1)
    assert(stringBitToInt('2')==None)
    assert(additionGF2m(0,0,8) == '00000000')
    assert(additionGF2m(3,4,8) == '00000111')
    assert(additionGF2m(3,3,8) == '00000000')

    assert(hex(int(additionGF2m(int('04', 16),int('a0', 16),8),2)) == '0xa4')
    assert(hex(int(additionGF2m(int('66', 16),int('fa', 16),8),2)) == '0x9c')
    assert(hex(int(additionGF2m(int('81', 16),int('fe', 16),8),2)) == '0x7f')
    assert(hex(int(additionGF2m(int('e5', 16),int('17', 16),8),2)) == '0xf2')
    assert(hexAdd('04', 'a0', 8) == 'a4')

    val1 = int(additionGF2m(43,138,8), 2)
    assert(int(additionGF2m(val1,1,8), 2) == 160)
    assert(int('000', 2) == 0)  # int('binary string', 2) => int version of bin
    assert(int('1', 2) == 1)
    assert(int('001', 2) == 1)
    assert(int('111', 2) == 7)
    assert(int(additionGF2m(3,4,8), 2) == 7)
    assert(multiplicationGF2m(7, 5, 11, 3) == '110')

    v00 = multiplicationGF2m(212, 2, 283, 8)
    v00 = int(v00, 2)
    v01 = multiplicationGF2m(191, 3, 283, 8)
    v01 = int(v01, 2)
    v02 = multiplicationGF2m(93, 1, 283, 8)
    v02 = int(v02, 2)
    v03 = multiplicationGF2m(48, 1, 283, 8)
    v03 = int(v03, 2)

    v0 = '0'
    v0 = additionGF2m(int(v0, 2), v00, 8)
    v0 = additionGF2m(int(v0, 2), v01, 8)
    v0 = additionGF2m(int(v0, 2), v02, 8)
    v0 = additionGF2m(int(v0, 2), v03, 8)

    assert(hex(int(v0,2)) == '0x4')
    assert(v0 == '00000100')

    v10 = multiplicationGF2m(212, 1, 283, 8)
    v10 = int(v10, 2)
    v11 = multiplicationGF2m(191, 2, 283, 8)
    v11 = int(v11, 2)
    v12 = multiplicationGF2m(93, 3, 283, 8)
    v12 = int(v12, 2)
    v13 = multiplicationGF2m(48, 1, 283, 8)
    v13 = int(v13, 2)

    v1 = '0'
    v1 = additionGF2m(int(v1, 2), v10, 8)
    v1 = additionGF2m(int(v1, 2), v11, 8)
    v1 = additionGF2m(int(v1, 2), v12, 8)
    v1 = additionGF2m(int(v1, 2), v13, 8)

    assert(hex(int(v1, 2)) == '0x66')

    v20 = multiplicationGF2m(212, 1, 283, 8)
    v20 = int(v20, 2)
    v21 = multiplicationGF2m(191, 1, 283, 8)
    v21 = int(v21, 2)
    v22 = multiplicationGF2m(93, 2, 283, 8)
    v22 = int(v22, 2)
    v23 = multiplicationGF2m(48, 3, 283, 8)
    v23 = int(v23, 2)

    v2 = '0'
    v2 = additionGF2m(int(v2, 2), v20, 8)
    v2 = additionGF2m(int(v2, 2), v21, 8)
    v2 = additionGF2m(int(v2, 2), v22, 8)
    v2 = additionGF2m(int(v2, 2), v23, 8)

    assert(hex(int(v2, 2)) == '0x81')

    v30 = multiplicationGF2m(212, 3, 283, 8)
    v30 = int(v30, 2)
    v31 = multiplicationGF2m(191, 1, 283, 8)
    v31 = int(v31, 2)
    v32 = multiplicationGF2m(93, 1, 283, 8)
    v32 = int(v32, 2)
    v33 = multiplicationGF2m(48, 2, 283, 8)
    v33 = int(v33, 2)

    v3 = '0'
    v3 = additionGF2m(int(v3, 2), v30, 8)
    v3 = additionGF2m(int(v3, 2), v31, 8)
    v3 = additionGF2m(int(v3, 2), v32, 8)
    v3 = additionGF2m(int(v3, 2), v33, 8)

    assert(hex(int(v3, 2)) == '0xe5')

    assert(hexMult('d4', '3', 283, 8) == hex(v30)[2:])

    mat0 = [
        ['02', '03', '01', '01'],
        ['01', '02', '03', '01'],
        ['01', '01', '02', '03'],
        ['03', '01', '01', '02']
    ]
    vec0 = ['d4', 'bf', '5d', '30']
    result0 = ['4','66','81','e5']
    assert(matXColvecGF2m(mat0, vec0, 283, 8) == result0)

    mat1 = [
        ['0e', '0b', '0d', '09'],
        ['09', '0e', '0b', '0d'],
        ['0d', '09', '0e', '0b'],
        ['0b', '0d', '09', '0e']
    ]
    assert(matXColvecGF2m(mat1, result0, 283, 8) == vec0)
    # mat1 is the left inverse of mat0
    assert(matXColvecGF2m(mat1, matXColvecGF2m(mat0, vec0, 283, 8)
                                                            , 283, 8) == vec0)
    # mat1 is the right inverse of mat0
    assert(matXColvecGF2m(mat0, matXColvecGF2m(mat1, result0, 283, 8)
                                                        , 283, 8) == result0)
    assert(aesMixCol(vec0) == matXColvecGF2m(mat0, vec0, 283, 8))

    print('...passed!\n')

testGF2mArithmetic()


# Sources:
# AES Rijndael Cipher explained as a Flash animation
# AppliedGo
# https://www.youtube.com/watch?v=gP4PqVGudtg
# 
# Lecture 7: Introduction to Galois Fields for the AES by Christof Paar
# Introduction to Cryptography by Christof Paar
# https://www.youtube.com/watch?v=x1v2tX4_dkQ
#
# Lecture 8: Advanced Encryption Standard (AES) by Christof Paar
# Introduction to Cryptography by Christof Paar
# https://www.youtube.com/watch?v=NHuibtoL_qk
#
# AES Proposal: Rijndael
# Joan Daemen, Vincent Rijmen
# https://csrc.nist.gov/csrc/media/projects/cryptographic-standards-and-guidelines/documents/aes-development/rijndael-ammended.pdf
#
# AES Specifications:
#
# Low Level:
#   Arithmetic is conducted under GF(2^8)
#   Usually thought of with polynomial representation
#   a_{m-1} x^{m-1} + ··· + a_1 x^1 + a_0 = A(x) ∊ GF(2^m)
#
#       Addition = Subtraction:
#           C(x) = A(x) + B(x) = Σ^{m-1}_{i=0} c_i x^i
#               c_i = a_i + b_i (mod 2)
#
#       Multiplication:
#           C(x) = A(x) · B(x) mod P(x)
#               P(x) = x^8 + x^4 + x^3 + x + 1
#                    = 100011011 (b)
#                    = 11b (0x)
#                    = 283 (10)
#               P(x) should be an Irreducible Polynomial to have an inverse
#
#       Multiplicative Inverse:
#           A(x) · A^{-1}(x) ≅ 1 mod P(x)
#           Do not need to compute this because we work on a table
#           (Byte Substitution)
#
#
# AES Encryption Transformations:
# 1) byteSubstitution
# 2) shiftRow
# 3) mixCol
# 4) keyAdd
#
#
# AES Encryption Process:
#
# input
# ↓
# 1) initial round (1 round)
#       keyAdd
#
# 2) main rounds (9 rounds)
#       byteSub
#       shiftRow
#       mixCol
#       keyAdd
#
# 3) final round (1 round)
#       byteSub
#       shiftRow
#       keyAdd
# ↓
# output
#
#
# AES Key Schedule:
#   Expansion of the given Cipher key into 11 partial keys